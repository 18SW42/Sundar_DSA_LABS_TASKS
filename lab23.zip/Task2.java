import java.util.Arrays;
public class Task2{
	public static void main(String args[]){
	int array1[]={1,2,3,4,5,6,7,8,9,10};
	int array2[]={1,2,3,4,5,6,7,8,9,10};
	System.out.println(Arrays.equals(array1,array2));
	}
}